/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package EntityKlassen;

import java.io.Serializable;
import java.security.SecureRandom;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author m.albrecht
 */
@Entity
@Table(name = "BENUTZER")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Benutzer.findAll", query = "SELECT b FROM Benutzer b"),
    @NamedQuery(name = "Benutzer.findById", query = "SELECT b FROM Benutzer b WHERE b.id = :id"),
    @NamedQuery(name = "Benutzer.findByName", query = "SELECT b FROM Benutzer b WHERE b.name = :name"),
    @NamedQuery(name = "Benutzer.findByVorname", query = "SELECT b FROM Benutzer b WHERE b.vorname = :vorname"),
    @NamedQuery(name = "Benutzer.findByGeburtsdatum", query = "SELECT b FROM Benutzer b WHERE b.geburtsdatum = :geburtsdatum"),
    @NamedQuery(name = "Benutzer.findByPersonalnummer", query = "SELECT b FROM Benutzer b WHERE b.personalnummer = :personalnummer"),
    @NamedQuery(name = "Benutzer.findByPasswort", query = "SELECT b FROM Benutzer b WHERE b.passwort = :passwort"),
    @NamedQuery(name = "Benutzer.findByWochenstunden", query = "SELECT b FROM Benutzer b WHERE b.wochenstunden = :wochenstunden"),
    @NamedQuery(name = "Benutzer.findByToken", query = "SELECT b FROM Benutzer b WHERE b.token = :token")})
public class Benutzer implements Serializable {

    @Size(max = 50)
    @Column(name = "NAME")
    private String name;
    @Size(max = 50)
    @Column(name = "VORNAME")
    private String vorname;
    @Size(max = 10)
    @Column(name = "GEBURTSDATUM")
    private String geburtsdatum;
    @Size(max = 6)
    @Column(name = "PERSONALNUMMER")
    private String personalnummer;
    @Size(max = 30)
    @Column(name = "PASSWORT")
    private String passwort;
    @Size(max = 64)
    @Column(name = "TOKEN")
    private String token;
    @OneToMany(mappedBy = "benutzer")
    private List<Buchung> buchungList;

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "ID")
    private Integer id;
    @Column(name = "WOCHENSTUNDEN")
    private Integer wochenstunden;

    public Benutzer() {
    }

    public Benutzer(Integer id) {
        this.id = id;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }


    public Integer getWochenstunden() {
        return wochenstunden;
    }

    public void setWochenstunden(Integer wochenstunden) {
        this.wochenstunden = wochenstunden;
    }
    
    public void setToken() {
        final int TOKEN_LENGTH = 64;
        final String CHARACTERS = "0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
        SecureRandom secureRandom = new SecureRandom();
        String neuesToken = "";
        for(int i = 0; i < TOKEN_LENGTH; i++)
        {
            neuesToken += CHARACTERS.charAt(secureRandom.nextInt(CHARACTERS.length()));
        }
        this.token = neuesToken;
    }
    
    public void deleteToken()
    {
        this.token = null;
    }


    @Override
    public int hashCode() {
        int hash = 0;
        hash += (id != null ? id.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Benutzer)) {
            return false;
        }
        Benutzer other = (Benutzer) object;
        if ((this.id == null && other.id != null) || (this.id != null && !this.id.equals(other.id))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "EntityKlassen.Benutzer[ id=" + id + " ]";
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getVorname() {
        return vorname;
    }

    public void setVorname(String vorname) {
        this.vorname = vorname;
    }

    public String getGeburtsdatum() {
        return geburtsdatum;
    }

    public void setGeburtsdatum(String geburtsdatum) {
        this.geburtsdatum = geburtsdatum;
    }

    public String getPersonalnummer() {
        return personalnummer;
    }

    public void setPersonalnummer(String personalnummer) {
        this.personalnummer = personalnummer;
    }

    public String getPasswort() {
        return passwort;
    }

    public void setPasswort(String passwort) {
        this.passwort = passwort;
    }

    public String getToken() {
        return token;
    }

    public void setToken(String token) {
        this.token = token;
    }

    @XmlTransient
    public List<Buchung> getBuchungList() {
        return buchungList;
    }

    public void setBuchungList(List<Buchung> buchungList) {
        this.buchungList = buchungList;
    }
    
}
