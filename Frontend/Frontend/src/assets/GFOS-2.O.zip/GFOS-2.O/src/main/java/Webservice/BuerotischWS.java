package Webservice;

import EJB.BuerotischEJB;
import EJB.BenutzerEJB;
import EntityKlassen.Buerotisch;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;



@Stateless
@LocalBean
@Path("/buerotisch")
public class BuerotischWS {
    private final Jsonb jsonb = JsonbBuilder.create();
    @EJB
    private BuerotischEJB buerotischEJB;
    @EJB
    private BenutzerEJB benutzerEJB;
   
    @GET
    @Path("/{token}/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("token") String token, @PathParam("id") int id) 
    {        
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        Buerotisch p = buerotischEJB.get(id);
        String buerotischJSON = jsonb.toJson(p);
        return Response.status(200).entity(buerotischJSON).build();    
    }
    
    @GET
    @Path("/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@PathParam("token") String token) {        
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        List<Buerotisch> liste = buerotischEJB.getAll();
        String json = jsonb.toJson(liste);
        return Response.status(200).entity(" {\"tischliste\":" + json + "}").build();    
    }
    
    @POST
    @Path("/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response create(@PathParam("token") String token, String idJSON)
    {
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        Buerotisch p = jsonb.fromJson(idJSON, Buerotisch.class);       
        buerotischEJB.add(p);
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();    
    }
    
    @PUT
    @Path("/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("token") String token, String BuerotischJSON)
    {    
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        Buerotisch p = jsonb.fromJson(BuerotischJSON, Buerotisch.class);
        buerotischEJB.update(p);
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();
    }
    
   
    @DELETE    
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{token}/{id}")
    public Response delete(@PathParam("token") String token, @PathParam("id") int id)
    {
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        buerotischEJB.delete(id);        
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();
    }
}
