
package EJB;

import EntityKlassen.Buchung;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
@LocalBean
public class BuchungEJB {
    
    @PersistenceContext
    private EntityManager em;
    
    //Read
    public Buchung get(int id){
        return em.find(Buchung.class, id);
    }
           
    //READ
    public List<Buchung> getAll() {
        return em.createNamedQuery("Buchung.findAll").getResultList();
    }
    
    //CREATE
    public void add(Buchung neuerBuchung) {
        em.persist(neuerBuchung);
    }
    
    //DELETE
    public boolean delete(int id) {
        try{
            em.remove(this.get(id));
            return true;
        }
        catch(IllegalArgumentException e){
            //Fehler: Objekt ist nicht persistiert
            return false;
        }
    }
    
    //DELETE by id
    public boolean delete(String id){
        try{
            Query query = em.createNamedQuery("Buchung.findById");
            Buchung b = (Buchung)query.getSingleResult();
            em.remove(b);
            return true;
        }
        catch(Exception e){
            return false;
        }
    }   
    // UPDATE
    /**
     * @param aktualisieterBuchung
     * @return true falls Update erfolgreich, sonst false
     */
    
    public boolean update(Buchung aktualisierteBuchung){
        int gesuchteId = aktualisierteBuchung.getId();
        try{
            Buchung aktuellInDatenbank = this.get(gesuchteId);
            aktuellInDatenbank.setId(aktualisierteBuchung.getId());
            return true;
        }
        catch(Exception e){
            return false;
        }
    }  
}