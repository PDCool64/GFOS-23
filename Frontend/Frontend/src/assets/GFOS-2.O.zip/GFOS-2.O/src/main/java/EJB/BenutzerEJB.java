
package EJB;

import EntityKlassen.Benutzer;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
@LocalBean
public class BenutzerEJB {
    
    @PersistenceContext
    private EntityManager em;
    
    //Read
    public Benutzer get(int id){
        return em.find(Benutzer.class, id);
    }       
    
    //READ
    public List<Benutzer> getAll() {
        return em.createNamedQuery("Benutzer.findAll").getResultList();
    }
    
    //CREATE
    public void add(Benutzer neuerBenutzer) {
        em.persist(neuerBenutzer);
    }
    
    //DELETE
    public boolean delete(int id) {
        try{
            em.remove(this.get(id));
            return true;
        }
        catch(IllegalArgumentException e){
            //Fehler: Objekt ist nicht persistiert
            return false;
        }
    }
    
    //DELETE by id
    public boolean delete(String id){
        try{
            Query query = em.createNamedQuery("Benutzer.findById");
            Benutzer b = (Benutzer)query.getSingleResult();
            em.remove(b);
            return true;
        }
        catch(Exception e){
            return false;
        }
    }   

     //Update
     /**
     * @param aktualisieterBenutzer
     * @return true falls Update erfolgreich, sonst false
     */
    
    public boolean update(Benutzer aktualisierterBenutzer){
        int gesuchteId = aktualisierterBenutzer.getId();
        try{
            Benutzer aktuellInDatenbank = this.get(gesuchteId);
            aktuellInDatenbank.setName(aktualisierterBenutzer.getName());
            aktuellInDatenbank.setVorname(aktualisierterBenutzer.getVorname());
            aktuellInDatenbank.setGeburtsdatum(aktualisierterBenutzer.getGeburtsdatum());
            aktuellInDatenbank.setPersonalnummer(aktualisierterBenutzer.getPersonalnummer());
            aktuellInDatenbank.setPasswort(aktualisierterBenutzer.getPasswort());
            aktuellInDatenbank.setWochenstunden(aktualisierterBenutzer.getWochenstunden());
            em.flush();
            return true;
        }
        catch(Exception e){
            return false;
        }
    }         
    
    public Benutzer login(String name, String passwort){
        try 
        {
            Benutzer gesuchterBenutzer = (Benutzer)em.createNamedQuery("Benutzer.findByName").setParameter("name", name).getSingleResult();            
            gesuchterBenutzer.setToken();
            em.flush();
            return gesuchterBenutzer;
        }
        catch(Exception e)
        {
            return null;
        }
    }
    
    public boolean logout(String token)
    {
        if(this.exists(token)) 
        {
            Benutzer gesuchterBenutzer = (Benutzer)em.createNamedQuery("Benutzer.findByToken").setParameter("token", token).getSingleResult();
            if(gesuchterBenutzer != null)
            {
                gesuchterBenutzer.deleteToken();
                em.flush();
                return true;
            }
        }
        return false;
    }
    
    public boolean exists(String token)
    {
        try 
        {
            Benutzer gesuchterBenutzer = (Benutzer)em.createNamedQuery("Benutzer.findByToken").setParameter("token", token).getSingleResult();
            return true;
        }
        catch(Exception e)
        {
            return false;
        }
        
    }
    
    public Benutzer getUserByToken(String token)
    {
        try 
        {
            Benutzer gesuchterBenutzer = (Benutzer)em.createNamedQuery("Benutzer.findByToken").setParameter("token", token).getSingleResult();
            return gesuchterBenutzer;
        }
        catch(Exception e)
        {
            return null;
        }
    }
}
