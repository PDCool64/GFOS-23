package Webservice;

import EJB.BenutzerEJB;
import EJB.BuchungEJB;
import EntityKlassen.Buchung;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;



@Stateless
@LocalBean
@Path("/buchung")
public class BuchungWS {
    private final Jsonb jsonb = JsonbBuilder.create();
    @EJB
    private BuchungEJB buchungEJB;
    @EJB
    private BenutzerEJB benutzerEJB;
   
    @GET
    @Path("/{token}/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("token") String token, @PathParam("id") int id) {        
        if(!benutzerEJB.exists(token))
        {
             return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        } 
        Buchung p = buchungEJB.get(id);
        String buchungJSON = jsonb.toJson(p);
        return Response.status(200).entity(buchungJSON).build();    
    }
    
    @GET
    @Path("/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("token") String token) {        
        if(!benutzerEJB.exists(token))
        {
             return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        } 
        List<Buchung> buchungen = buchungEJB.getAll();
        String buchungJSON = jsonb.toJson(buchungen);
        return Response.status(200).entity(" {\"buchungliste\":" + buchungJSON + "}").build(); 
    }
    
    @POST
    @Path("/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response create(@PathParam("token") String token, String buchungJSON)
    {
        if(!benutzerEJB.exists(token))
        {
             return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        System.out.println(buchungJSON);
        String startdatum = buchungJSON.substring(15,31);
        String enddatum = buchungJSON.substring(45,61);        
        Buchung neueBuchung = jsonb.fromJson(buchungJSON, Buchung.class);
        neueBuchung.getBenutzer().setBuchungList(null);
        neueBuchung.getTisch().setBuchungList(null);
        neueBuchung.setStartdatum(startdatum);
        neueBuchung.setEnddatum(enddatum);
         List<Buchung> alle = buchungEJB.getAll();
         /*for(Buchung b: alle)
         {
             if((neueBuchung.getStartdatum().compareTo(b.getStartdatum()) >= 0 && 
                 neueBuchung.getStartdatum().compareTo(b.getEnddatum()) <= 0) ||
                (neueBuchung.getEnddatum().compareTo(b.getStartdatum()) >= 0 && 
                 neueBuchung.getEnddatum().compareTo(b.getEnddatum()) <= 0)                     
               )
               {
                return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();
               }            
          }*/
         buchungEJB.add(neueBuchung);
         return Response.status(200).entity(" {\"status\":\"ok\" } ").build();      
    }
    
    @PUT
    @Path("/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("token") String token, String BuchungJSON)
    {        
        if(!benutzerEJB.exists(token))
        {
             return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        Buchung p = jsonb.fromJson(BuchungJSON, Buchung.class);
        buchungEJB.update(p);
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();
    }
    
   
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{token}/{id}")
    public Response delete(@PathParam("token") String token, @PathParam("id") int id)
    {
        if(!benutzerEJB.exists(token))
        {
             return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        buchungEJB.delete(id);        
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();
    
        
    }       
}