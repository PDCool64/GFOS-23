package Webservice;

import EJB.BenutzerEJB;
import EntityKlassen.Benutzer;
import java.util.List;
import javax.ejb.EJB;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.json.bind.Jsonb;
import javax.json.bind.JsonbBuilder;
import javax.ws.rs.Consumes;
import javax.ws.rs.DELETE;
import javax.ws.rs.GET;
import javax.ws.rs.POST;
import javax.ws.rs.PUT;
import javax.ws.rs.Path;
import javax.ws.rs.PathParam;
import javax.ws.rs.Produces;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;



@Stateless
@LocalBean
@Path("/benutzer")
public class BenutzerWS {
    private final Jsonb jsonb = JsonbBuilder.create();
    @EJB
    private BenutzerEJB benutzerEJB;
   
    @GET
    @Path("/{token}/{id}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response get(@PathParam("token") String token, @PathParam("id") int id) {        
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        Benutzer p = benutzerEJB.get(id);
        String benutzerJSON = jsonb.toJson(p);
        return Response.status(200).entity(benutzerJSON).build();    
    }
    
    @GET
    @Path("/userFrom/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getUserFrom(@PathParam("token") String token) {        
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        try 
        {
            Benutzer p = benutzerEJB.getUserByToken(token);
            String benutzerJSON = jsonb.toJson(p);
            return Response.status(200).entity(benutzerJSON).build();    
        }
        catch(Exception e)
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build(); 
        }
    }
    
    @GET
    @Path("/{token}")
    @Produces(MediaType.APPLICATION_JSON)
    public Response getAll(@PathParam("token") String token) {        
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        List<Benutzer> benutzerliste = benutzerEJB.getAll();
        String benutzerJSON = jsonb.toJson(benutzerliste);
        return Response.status(200).entity(" {\"benutzerliste\":" + benutzerJSON + "}").build();    
    }
    
    @POST
    @Path("/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response create(@PathParam("token") String token, String idJSON)
    {
        if(!benutzerEJB.exists(token))
        {
             return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        } 
        Benutzer p = jsonb.fromJson(idJSON, Benutzer.class);
        benutzerEJB.add(p);
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();    
    }
        
    @DELETE
    @Produces(MediaType.APPLICATION_JSON)
    @Path("/{token}/{id}")
    public Response delete(@PathParam("token") String token, @PathParam("id") int id)
    {
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        benutzerEJB.delete(id);        
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();
    }
    
    @POST
    @Path("/login")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response login(String PersonalnummerJSON)
    {
       Benutzer eingabe = jsonb.fromJson(PersonalnummerJSON, Benutzer.class);
       Benutzer benutzerAusDB = benutzerEJB.login(eingabe.getName(), eingabe.getPasswort());
       if(benutzerAusDB == null)
       {
           return Response.status(200).entity(" {\"token\":\"\" } ").build();
       }    
       else
       {
           return Response.status(200).entity(" {\"token\":\""+benutzerAusDB.getToken()+"\" } ").build();
       }
    }
    
    @PUT
    @Path("/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    @Produces(MediaType.APPLICATION_JSON)
    public Response update(@PathParam("token") String token, String BenutzerJSON)
    {   
        if(!benutzerEJB.exists(token))
        {
            return Response.status(200).entity(" {\"status\":\"nicht ok\" } ").build();   
        }
        Benutzer p = jsonb.fromJson(BenutzerJSON, Benutzer.class);
        benutzerEJB.update(p);
        return Response.status(200).entity(" {\"status\":\"ok\" } ").build();
    }

    @POST
    @Path("/logout/{token}")
    @Consumes(MediaType.APPLICATION_JSON)
    public Response logout(@PathParam("token") String token)
    {
       
       if(benutzerEJB.logout(token) == true)
       {
           return Response.status(200).entity(" {\"token\":\"\" } ").build(); 
       }
       else
       {            
            return Response.status(200).entity(" {\"token\":\""+token+"\" } ").build();
        }
    }


}