package EJB;

import EntityKlassen.Buerotisch;
import java.util.List;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;
import javax.persistence.Query;

@Stateless
@LocalBean
public class BuerotischEJB {
    
    @PersistenceContext
    private EntityManager em;
    
    //Read
    public Buerotisch get(int id){
        return em.find(Buerotisch.class, id);
    }

    
    //READ
    public List<Buerotisch> getAll() {
        return em.createNamedQuery("Buerotisch.findAll").getResultList();
    }
    
    //CREATE
    public void add(Buerotisch neuerBuerotisch) {
        em.persist(neuerBuerotisch);
    }
    
    //Create ohne Parameter
    public void create() {
        em.persist(new Buerotisch());
    }
    
    //DELETE
    public boolean delete(int id) {
        try{
            em.remove(this.get(id));
            return true;
        }
        catch(IllegalArgumentException e){
            //Fehler: Objekt ist nicht persistiert
            return false;
        }
    }
    
    //DELETE by id
    public boolean delete(String id){
        try{
            Query query = em.createNamedQuery("Buerotisch.findById");
            Buerotisch b = (Buerotisch)query.getSingleResult();
            em.remove(b);
            return true;
        }
        catch(Exception e){
            return false;
        }
    }   
    // UPDATE
    /**
     * @param aktualisierterBuerotisch
     * @return true falls Update erfolgreich, sonst false
     */
    
    public boolean update(Buerotisch aktualisierterBuerotisch){
        int gesuchteId = aktualisierterBuerotisch.getId();
        try{
            Buerotisch aktuellInDatenbank = this.get(gesuchteId);
            aktuellInDatenbank.setName(aktualisierterBuerotisch.getName());
            aktuellInDatenbank.setRaum(aktualisierterBuerotisch.getRaum());
            return true;
        }
        catch(Exception e){
            return false;
        }
    }  
}